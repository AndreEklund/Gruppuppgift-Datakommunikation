package entity;

public class OnlineListMessage {
}
